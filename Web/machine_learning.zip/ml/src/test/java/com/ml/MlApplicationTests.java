package com.ml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MlApplicationTests {

    @Test
    void contextLoads() {
    }

}
